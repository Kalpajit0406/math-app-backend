import { Router } from "express";

import { 
    registerStudent, 
    loginStudent, 
    logoutStudent, 
    updateStudentClass,
    updateStudentLanguage,
    getAllStudents, 
    acceptStudent, 
    rejectStudent,
    bulkDeleteStudents,
    bulkAcceptStudents,
    getVerifiedStudents,
    // getPendingStudents,
} from "../controllers/student.controller.js";

import { verifyJWT } from "../middlewares/auth.middleware.js";

const router = Router();

// Register a new student
router.route("/register").post(registerStudent);
// Login a student
router.route("/login").post(loginStudent);


// Logout a student
router.route("/logout").post(verifyJWT, logoutStudent);
router.route("/update-class").patch(verifyJWT, updateStudentClass);
router.route("/update-language").patch(verifyJWT, updateStudentLanguage);


// Get all students
router.route("/students").get(getAllStudents);

// Accept or reject student registration
router.route("/accept/:id").put(verifyJWT, acceptStudent);
router.route("/reject/:id").delete(verifyJWT, rejectStudent);
router.route("/bulk-delete").delete(verifyJWT, bulkDeleteStudents);
router.route("/bulk-accept").put(verifyJWT, bulkAcceptStudents);

// // Get verified and pending students
router.route("/verified").get(getVerifiedStudents);
// router.route("/pending").get(verifyJWT, getPendingStudents);   

// Get students by class
// router.get("/students/class/:classNo", getStudentsByClass);      
// Get students by language preference  
// router.get("/students/language/:language", getStudentsByLanguage);
export default router;

import { Router } from "express";
import { saveStudentTest, checkTestResponse, getStudentTestResponse,  getAllTestResponses, deleteAllTestResponsesById } from "../controllers/testRespose.controller.js";
import { verifyJWT } from "../middlewares/auth.middleware.js";

const router = Router();

router.route("/")
  .post(verifyJWT, saveStudentTest);

router.route("/:studentMobile")   
  .get(getStudentTestResponse);

router.route("/check/:studentMobile/:testId")
  .get(checkTestResponse);
  
router.route("/res/all")
    .get(getAllTestResponses);

router.route("/delete/:testId")
  .delete(deleteAllTestResponsesById);    

export default router;  

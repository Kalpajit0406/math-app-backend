import mongoose, { Document, Schema } from "mongoose";
import jwt, { SignOptions } from "jsonwebtoken";
import bcrypt from "bcrypt";

interface IStudent extends Document {
  fullName: string;
  studentMobile: string;
  classNo: 9 | 10 | 11 | 12;
  guardianName?: string;
  guardianMobile: string;
  password: string;
  refreshToken?: string;
  verified: boolean;
  language: string; // Fix 1: was `String` (object wrapper type), should be `string` (primitive)
  createdAt: Date;
  updatedAt: Date;

  isPasswordCorrect(inputPassword: string): Promise<boolean>;
  generateAccessToken(): string;
  generateRefreshToken(): string;
}

const studentSchema = new Schema<IStudent>(
  {
    fullName: {
      type: String,
      required: [true, "Full Name is required"],
      trim: true,
      index: true,
    },
    studentMobile: {
      type: String,
      required: [true, "Mobile number is required"],
      unique: true,
      trim: true,
      index: true,
      validate: {
        validator: function (v: string) {
          return /^[6-9]\d{9}$/.test(v);
        },
        message: (props: { value: string }) => // Fix 2: replaced `any` with a proper type
          `${props.value} is not a valid mobile number!`,
      },
    },
    classNo: {
      type: Number,
      enum: [9, 10, 11, 12],
      required: [true, "Class is required"],
    },
    guardianName: {
      type: String,
      trim: true,
      index: true,
    },
    guardianMobile: {
      type: String,
      required: [true, "Guardian mobile number is required"],
      // Note: `unique: true` here may cause issues if multiple students share a guardian.
      // Remove if guardians can have more than one student.
      //unique: true,
      trim: true,
      index: true,
      validate: {
        validator: function (v: string) {
          return /^[6-9]\d{9}$/.test(v);
        },
        message: (props: { value: string }) => // Fix 3: replaced `any` with a proper type
          `${props.value} is not a valid mobile number!`,
      },
    },
    password: {
      type: String,
      required: [true, "Password is required"],
      minlength: [6, "Password must be at least 6 characters long"],
    },
    refreshToken: {
      type: String,
    },
    verified: {
      type: Boolean,
      default: false,
    },
    language: {
      type: String,
      enum: ["Bengali", "English"],
      required: [true, "Preferred language is required"],
    },
  },
  {
    timestamps: true,
  }
);

// Hash password before saving
studentSchema.pre<IStudent>("save", async function (next) {
  if (!this.isModified("password")) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

// Compare password method
studentSchema.methods.isPasswordCorrect = async function (
  this: IStudent,
  inputPassword: string
): Promise<boolean> {
  return await bcrypt.compare(inputPassword, this.password);
};

// Generate access token
studentSchema.methods.generateAccessToken = function (this: IStudent): string {
  // Fix 4: Construct SignOptions cleanly; no need for `as any` cast on jwt.sign
  const options: SignOptions = {
    expiresIn: (process.env.ACCESS_TOKEN_EXPIRY ?? "7d") as SignOptions["expiresIn"],
  };

  return jwt.sign(
    {
      _id: this._id,
      studentMobile: this.studentMobile,
      fullName: this.fullName,
    },
    process.env.ACCESS_TOKEN_SECRET as string,
    options
  );
};

// Generate refresh token
studentSchema.methods.generateRefreshToken = function (this: IStudent): string {
  // Fix 5: Same fix as above — clean cast, no `as any`
  const options: SignOptions = {
    expiresIn: (process.env.REFRESH_TOKEN_EXPIRY ?? "30d") as SignOptions["expiresIn"],
  };

  return jwt.sign(
    {
      _id: this._id,
    },
    process.env.REFRESH_TOKEN_SECRET as string,
    options
  );
};

export const Student = mongoose.model<IStudent>("Student", studentSchema);